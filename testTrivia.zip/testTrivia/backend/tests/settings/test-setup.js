import { beforeAll, beforeEach, afterAll, afterEach } from 'vitest';

// you can even use the setup/teardown methods
beforeAll(() => {
  // your code
});
beforeEach(() => {
  // your code
});
afterEach(() => {
  // your code
});
afterAll(() => {
  // your code
});
